#pragma once

#define QCOR_INSTALL_DIR "/usr/local/xacc"
#define XACC_ROOT "/usr/local/xacc"
